long cread_alt(long *xp) {
    return (!xp? -1 : xp[-1]);
}
